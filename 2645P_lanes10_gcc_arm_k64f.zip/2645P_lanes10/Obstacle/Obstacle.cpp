#include "Obstacle.h"


Obstacle::Obstacle()
{

}

Obstacle::~Obstacle()
{

}

void Obstacle::init2D(int speed){
     
     Ticker ticker;

     //ticker.attach(&xRandom,0.1);
     
     xRandom();
     
     _obsize = 15;
     _velocity.y = speed + 3;
     //_x = 35;
     
}

void Obstacle::draw2D(N5110 &lcd){

    lcd.drawRect(_x,_y,_obsize, 7,FILL_BLACK);

}

void Obstacle::xRandom(){
    //Produces random number of 256
    int xPosition = rand() % 256;
    
    //printf ("xRandom = %d", xPosition);
    //Randomiser split into three equal number groups that it can fall into 
    if (xPosition <= 85 && xPosition >= 0){
        //printf ("%s \n", "Middle Obstacle Release");
        _x=35;
        }
    else if (xPosition <= 170 && xPosition >= 86){
        _x=17;
        //printf ("%s \n", "Left Obstacle Release");
        }
    else if (xPosition <= 256 && xPosition >= 171){
        _x=53;
        //printf ("%s \n", "Right Obstacle Release");
        }
}    

void Obstacle::positionSet()
{
    if (_y > HEIGHT){
        xRandom();
        _y = 0;
        }
    
    _x += _velocity.x;
    _y += _velocity.y;
}

void Obstacle::velocitySet(Vector2D v)
{
    _velocity.x = v.x;
    _velocity.y = v.y;
}

Vector2D Obstacle::velocityGet()
{
    Vector2D v = {_velocity.x,_velocity.y};
    return v;
}

Vector2D Obstacle::positionGet()
{
    Vector2D p = {_x,_y};
    return p;
}

void Obstacle::set_pos(Vector2D p)
{
    _x = p.x;
    _y = p.y;
}
