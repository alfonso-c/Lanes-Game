#ifndef Obstacle_H
#define Obstacle_H

#include "mbed.h"
#include "N5110.h"
#include "Gamepad.h"

/** Obstacle Class
@brief Library for interfacing with the obstacle


*/

class Obstacle
{
public:

    Obstacle();
    /**
     * Free allocated memory when object goes out of scope
     */
    ~Obstacle();
    /** Initialise Obstacle
    *   Initilases parameters for the obstacle
    *   @param speed - speed of the game 
    */
    void init2D(int speed);
    /** Draw Obstacle
    *   Function to draw the Obstacle at given parameters
    */
    void draw2D(N5110 &lcd);
    /** x Randomiser
    *   Randomises the value of x 
    */
    void xRandom();
    /** Position Set
    *   Function to set the position of the Obstacle
    */
    void positionSet();
    /// accessors and mutators
    /** Velocity Set
    *   Function to set the velocity of the Obstacle
    */
    void velocitySet(Vector2D v);
    /** Velocity Get
    *   Function to get the velocity of the Obstacle
    */
    Vector2D velocityGet();
    /** Position Get
    *   Gets the velocity of the Obstacle in the form of an array using Vector2D
    */
    Vector2D positionGet();
    /** Vector Position Set
    *   Gets the position of the Obstacle in the form of an array using Vector2D
    */
    void set_pos(Vector2D p);
    

private:

    //Obstacle parameters
    int y;
    int _x;
    int _xOb;
    int _y;
    int _speed;
    int position;
    int _obsize; //size of the obstacle
    Vector2D _velocity;

};
#endif