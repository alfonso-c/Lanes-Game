#ifndef CARENGINE_H
#define CARENGINE_H

#include "mbed.h"
#include "N5110.h"
#include "Gamepad.h"
#include "Glider.h"
#include "Obstacle.h"
#include "Bullet.h"
#include "Bitmap.h"
#include "Powerup.h"
#include "Coins.h"
#include "Coins3D.h"
#include "Sprite2D.h"


#define GAP 2

/** Engine Class
@brief Library for collecting all the objects and outputing the values of each


*/

class CarEngine
{

public:
    CarEngine();
    ~CarEngine();
    /** Initialise Engine
    *   Initilases parameters for the engine
    *   @param speed - speed of the game 
    */
    void init(int speed);
    /** Read Input
    *   Reads the input from the gamepad
    */
    void read_input(Gamepad &pad);
    /** Update
    *   Updates values of game parameters
    */
    void update(Gamepad &pad, N5110 &lcd);
    /** Draw
    *   Draws the objects such as the Glider, Obtacle, Coin, Points and Lives
    */
    void draw(N5110 &lcd);
    /** Draw 3D Lanes
    *   Draws the outer and inside lanes for the 3D version
    *   (Unused)
    */
    void drawLanes3D(N5110 &lcd);
    
private:
    /** Collision Get
    *   Determines whether the glider has collided with the obstacle
    */
    void collisionGet(Gamepad &pad, N5110 &lcd);
    /** Check 3D Powerup
    *   Determines whether the glider has picked up the 3D powerup
    */
    void check_power3D(Gamepad &pad);
    /** Check Points
    *   Determines whether the glider has picked up a coin
    */
    void check_points(Gamepad &pad);
    /** Print Points
    *   Displays the number of points the user has collected 
    */
    void print_points(N5110 &lcd);
    /** Print Lives
    *   Displays the number of lives the user has left in the form of heart shapes 
    */
    void print_lives(N5110 &lcd);
    /** Gameover
    *   Displays gameover screen when the user has lost all four lives, displays number of points at the end 
    */
    void gameover(N5110 &lcd, int speed, Gamepad &pad);
    
    ///////// Object definitions ////////
    Glider _g;
    Obstacle _ob;
    Bullet _bul;
    Coins _coin;
    Coins3D _coin3D;
    Powerup _pwrup;
    Sprite2D sprited;
    Gamepad pad;
     
    ///////// Engine Parameters ////////
    int _speed;
    int g_width;
    int g_height;
    int ob_width;
    int ob_height;
    
    int xg;
    int yg;
    int xob;
    int yob;
    int _x;
    int _xOb;
    
    // y position of glider
    int _gy;
    
    Direction _d;
    float _mag;

};

#endif