#include "CarEngine.h"

CarEngine::CarEngine()
{

}

CarEngine::~CarEngine()
{

}
// initialise the game parameters
void CarEngine::init(int speed)
{
    //printf("%s", "Engine Initialised");

    _speed = speed; // sets game speed to define value

    // set parameters for the glider and obstacle dimensions
    g_width = 15;
    g_height = 8;
    ob_width = 15;
    ob_height = ob_width/2;

    _gy = GAP;

    _g.init(_gy);
    _coin3D.init3D(_speed);
    _ob.init2D(_speed);
    _bul.init(_speed);
    _coin.init2D(_speed);
    _pwrup.init2D(_speed);

}

// Reads the input from the gamepad
void CarEngine::read_input(Gamepad &pad)
{
    _d = pad.get_direction();
    _mag = pad.get_mag();
    //printf("%s", "Read input");
    //printf("Pad direction = %d", _d);
    //printf("Pad mag = %d", _mag);
}

// Draws the objects such as the Glider, Obtacle, Coin, Points and Lives
void CarEngine::draw(N5110 &lcd)
{
    print_points(lcd);
    print_lives(lcd);

    _g.draw(lcd);

    //2D Drawers
    _ob.draw2D(lcd);
    _coin.draw2D(lcd);
    _pwrup.draw2D(lcd);

    //Uncomment these two functions and comment out 2D drawers to use 3D mode
    /*
    _coin3D.draw3DC(lcd);
    drawLanes3D(lcd);
    */
    //printf("%s", "Engine Draw");
}

//Draws the outer and inside lanes for the 3D version
void CarEngine::drawLanes3D(N5110 &lcd)
{
    //x0,y0,x1,y1,type 0-white,1-black,2-dotted
    lcd.drawLine(0,12,WIDTH,12,1);
    //Outside Lanes 3D
    lcd.drawLine(0,HEIGHT,34,13,1);
    lcd.drawLine(WIDTH,HEIGHT,WIDTH-35,13,1);
    //Inside Lanes 3D
    lcd.drawLine(28,HEIGHT,40,12,1);
    lcd.drawLine(55,HEIGHT,43,12,1);
    //printf("%s", "3D Lanes Drawn");
}

// Updates values of game parameters
void CarEngine::update(Gamepad &pad,N5110 &lcd)
{
    check_points(pad);
    check_power3D(pad);
    _g.positionSet(_d,_mag);
    collisionGet(pad, lcd);
    //_bul.positionSet();
    
    _ob.positionSet();
    _coin.positionSet();
    _pwrup.positionSet();
    
    //Uncomment this function and comment out positionSets above to use 3D mode
    //_coin3D.positionSetC();

    gameover(lcd, _speed, pad);

    //printf("%s", "Engine Update");
}

// Determines whether the glider has collided with the obstacle
void CarEngine::collisionGet(Gamepad &pad, N5110 &lcd)
{
    //re-define obstacle and glider parameters
    g_width = 14;
    g_height = 6;
    ob_width = 14;
    ob_height = 6;

    _xOb = _x;

    // check Glider and Obstacle Position
    Vector2D g_position = _g.positionGet();
    Vector2D ob_position = _ob.positionGet();

    if (
        (ob_position.y + ob_height >= HEIGHT - 11) && //top of glider touches bottom of object
        (ob_position.y <= HEIGHT-2)&&  //bottom of glider touches top of obstacle
        (ob_position.x + ob_width >= g_position.x) && //left of glider touhces right of obstacle
        (ob_position.x <= g_position.x + g_width)  //right of glider touches left of obstacle
    ) {
        _ob.xRandom(); //randomise x position of the obstacle
        _g.take_lives(); //take a life when collision occurs
        ob_position.y = 0; //reset y value of obstacle to the top
        //printf("Obstacle Collision");
        pad.tone(100.0,0.5); //collision feedback
    }
    _ob.set_pos(ob_position); //set y value of obstacle

}

//Determines whether the glider has picked up the 3D powerup
void CarEngine::check_power3D(Gamepad &pad)
{
    // check Glider and 3D Powerup Position
    Vector2D g_position = _g.positionGet();
    Vector2D pwrup_position = _pwrup.positionGet();

    if (
        (pwrup_position.y + 6 >= HEIGHT-11) && //top
        //(pwrup_position.y <= HEIGHT-2)&&  //bottom
        (pwrup_position.x + 6 >= g_position.x) && //left
        (pwrup_position.x <= g_position.x + 11)  //right
    ) {
        pwrup_position.y = 0;
        //printf("Powerup Collected");
        pad.tone(3000.0,0.1);
    }
    _pwrup.set_pos(pwrup_position);
}

//Determines whether the glider has picked up a coin
void CarEngine::check_points(Gamepad &pad)
{
    // check Glider and Coin Position
    Vector2D g_position = _g.positionGet();
    Vector2D coin_position = _coin.positionGet();

    if (
        (coin_position.y + 6 >= HEIGHT-12) && //top
        //(coin_position.y <= HEIGHT-2)&&  //bottom
        (coin_position.x + 6 >= g_position.x) && //left
        (coin_position.x <= g_position.x + 14)  //right
    ) {
        _coin.xRandom();
        coin_position.y = 0; //resets coin position to top of screen
        _coin.set_pos(coin_position);
        _g.add_points();
        _coin.init2D(_speed);
        pad.tone(2100.0,0.1); //audio feedback when coin is collected
        //printf("Point Collected");
    }
    _coin.set_pos(coin_position);

}

// Displays the number of points the user has collected
void CarEngine::print_points(N5110 &lcd)
{
    // get points from collecting coins
    int g_points = _g.get_points();
    //printf("Points = %d", g_points);

    // display scores on screen
    char buffer1[1];
    sprintf(buffer1,"%2d",g_points);
    lcd.printString(buffer1,1,0);  // font is 8 wide, so leave 4 pixel gape from middle assuming two digits
}

// Displays the number of lives the user has left in the form of heart shapes
void CarEngine::print_lives(N5110 &lcd)
{
    // get value for number of current lives, initial is 4
    int g_lives = _g.check_lives();
    //printf("Lives = %d", g_lives);

    if (g_lives == 4) {
        sprited.drawHeart(lcd);
    } else if(g_lives == 3) {
        sprited.drawOneLifeGone(lcd);
    } else if(g_lives == 2) {
        sprited.drawTwoLivesGone(lcd);
    } else if(g_lives == 1) {
        sprited.drawThreeLivesGone(lcd);
    } else if(g_lives == 0) {
        sprited.drawAllLivesGone(lcd);
    }


}

// Displays gameover screen when the user has lost all four lives, displays number of points at the end
void CarEngine::gameover(N5110 &lcd, int speed, Gamepad &pad)
{
    //printf("%s", "Game Over");
    _speed = speed;
    int g_points = _g.get_points();// get value of points
    int _g_lives = _g.check_lives(); // get number of lives
    // if number of lives goes to zero, game over occurs
    if (_g_lives == 0) {
        int count = 0; //sets internal counter for gameover screen
        lcd.clear();
        //"GAME OVER" flahes for a few seconds before moving to end display
        while (count <= 5) {
            lcd.printString("   GAME OVER   ",0,2);
            lcd.refresh();
            wait(0.25);
            lcd.clear();
            lcd.refresh();
            count++;
            wait(0.25);
        }
        init(_speed);
        lcd.clear();
        //Displays score received from the most recent game
        lcd.printString("  Your Score:   ",0,1);
        lcd.drawRect(30,HEIGHT/2-4,20,15,FILL_TRANSPARENT);
        char buffer1[1];
        sprintf(buffer1,"%2d",g_points);
        lcd.printString(buffer1,WIDTH/2-10,3);
        lcd.printString("  Press Back ",0,5);
        lcd.refresh();

        // wait flashing LEDs until back button is pressed
        while ( pad.check_event(Gamepad::BACK_PRESSED) == false) {
            pad.leds_on();
            wait(0.1);
            pad.leds_off();
            wait(0.1);
        }
    }

}