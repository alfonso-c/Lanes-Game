#include "Coins3D.h"


Coins3D::Coins3D()
{

}

Coins3D::~Coins3D()
{

}

void Coins3D::init3D(int speed){
    r = 2; // Width & height for centre Coins3D
    r3 = 3; //Width & height for left/Right Coins3D
    
    //Values for the  starting x and y positions of Coins3Ds
    yd = 0;
    xd = 0;
    ydl = 0;
    xdl = 0;
    _velocity.y = speed;
}

void Coins3D::draw3DL(N5110 &lcd)
{
    
    // draw Coins3D
    //          origin x,y,width,height,type
    // lcd.drawRect(41,14,2,2,FILL_BLACK);  // filled black rectangle
    lcd.drawRect(35 + xdl,14+ydl,r3,r3,FILL_TRANSPARENT);  // filled black rectangle

    r3 = r3 + 1;
    ydl = ydl + 2;
    xdl = xdl - 2;

    if (r3 == 20 && 35 + xdl == 1 && 14 + ydl == HEIGHT) {
        r3 = 3;
        xdl = 0;
        ydl = 0;
    }

}

void Coins3D::draw3DC(N5110 &lcd)
{
    lcd.drawRect(41 + _x,13 + _y,r,r,FILL_TRANSPARENT);  // filled black rectangle
/*
    
    yd = yd + 3;
    xd = xd - 1;
*/
    r = r + 2;
    if (r == 26 && 41 + _x == 29 && 13 + _x == HEIGHT+1) {
        r = 2;
        xd = 0;
        yd = 0;
    }
}

   

void Coins3D::positionSetC()
{
    if (_y > HEIGHT){
        xRandom();
        _y = 0;
        r = 4;
        _x = 0;
        }
    
    _x = _x - 1;
    _y =_y + 3;


/*
    xd -= xd - 1;
    yd += yd + 3;
*/
}

void Coins3D::velocitySetC(Vector2D v)
{
    _velocity.x = v.x;
    _velocity.y = v.y;
}

Vector2D Coins3D::velocityGetC()
{
    Vector2D v = {_velocity.x,_velocity.y};
    return v;
}

Vector2D Coins3D::positionGetC()
{
    Vector2D p = {_x,_y};
    return p;
}

void Coins3D::set_posC(Vector2D p)
{
    _x = p.x;
    _y = p.y;
}

void Coins3D::xRandom(){
    int xPosition = rand() % 1000;
    
    printf ("xRandom = %d", xPosition);
    
    if (xPosition <= 85 && xPosition >= 0){
        printf ("%s \n", "Middle Coins3D Release");
        _x=35;
        }
    else if (xPosition <= 170 && xPosition >= 86){
        _x=17;
        printf ("%s \n", "Left Coins3D Release");
        }
    else if (xPosition <= 256 && xPosition >= 171){
        _x=53;
        printf ("%s \n", "Right Coins3D Release");
        }
    
} 

#pragma 3D Coins3D section
/*
void Coins3D::draw3DL(N5110 &lcd)
{
    
    // draw Coins3D
    //          origin x,y,width,height,type
    // lcd.drawRect(41,14,2,2,FILL_BLACK);  // filled black rectangle
    lcd.drawRect(35 + xdl,14+ydl,r3,r3,FILL_BLACK);  // filled black rectangle

    r3 = r3 + 1;
    ydl = ydl + 2;
    xdl = xdl - 2;

    if (r3 == 20 && 35 + xdl == 1 && 14 + ydl == HEIGHT) {
        r3 = 3;
        xdl = 0;
        ydl = 0;
    }

}

void Coins3D::draw3DC(N5110 &lcd)
{
    lcd.drawRect(41 + xd,13+yd,r,r,FILL_BLACK);  // filled black rectangle

    r = r + 2;
    yd = yd + 3;
    xd = xd - 1;

    if (r == 26 && 41 + xd == 29 && 13 + yd == HEIGHT+1) {
        r = 2;
        xd = 0;
        yd = 0;
    }
}
*/