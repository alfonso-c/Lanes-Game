#ifndef Coins3D_H
#define Coins3D_H

#include "mbed.h"
#include "N5110.h"
#include "Gamepad.h"

class Coins3D
{
public:

    Coins3D();
    ~Coins3D();
    void init(int x,int height,int width);
    //void init3D(int r, int r3, int yd, int xd, int ydl, int xdl);
    
    void init3D(int speed);
    void draw2D(N5110 &lcd);
    void draw3DL(N5110 &lcd);
    void draw3DC(N5110 &lcd);
    void draw3DR(N5110 &lcd);
    
    void init2D(int speed);
    
    void xRandom();
    void positionSetC();
    /// accessors and mutators
    void velocitySetC(Vector2D v);
    Vector2D velocityGetC();
    Vector2D positionGetC();
    void set_posC(Vector2D p);
    

private:

    //Ticker ticker;

    int y;
    int _x;
    int _xOb;
    int _y;
    int _speed;
    int _score;
    int position;
    
    int _obsize;
    
    //int _r;
    int r;
    
    //Parameters for 3D Coins3D, 
    // r3 is the increasing 3d length
    //xd & yd 
    int r3;
    int yd;
    int xd;
    int ydl;
    int xdl;
    
    Vector2D _velocity;

};
#endif